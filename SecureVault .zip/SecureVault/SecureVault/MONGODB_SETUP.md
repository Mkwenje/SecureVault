# SecureVault MongoDB setup

SecureVault now uses MongoDB as its only database. Audit logging and all SQLite
code have been removed.

## Collections

The application creates and uses:

- `users` — usernames, PBKDF2 password hashes/salts, TOTP secrets and RSA keys.
- `file_records` — encrypted file paths and RSA-wrapped AES keys.

The encrypted file contents remain on the user's computer; MongoDB stores the
application records required to authenticate and decrypt them.

## Configure the connection securely

Do not place an Atlas username or password in `MongoConnection.java`.
Configure either:

- Environment variable: `MONGODB_URI`
- JVM option: `-Dmongodb.uri=<connection-string>`

Optional database name:

- Environment variable: `MONGODB_DATABASE`
- JVM option: `-Dmongodb.database=<database-name>`

The default database name is `securevault`.

### NetBeans (recommended)

1. Right-click the project and choose **Properties**.
2. Open **Run**.
3. Add the following under **VM Options**:

   `-Dmongodb.uri=mongodb+srv://<user>:<password>@<cluster>/?appName=<app>`

4. Run the project.

For a team or submitted project, prefer an operating-system environment variable
so the password is not saved in project files.

## Existing SQLite users

SQLite records are not read by this version. Register users again so their
password hash, TOTP secret and RSA key pair are created in MongoDB. Existing
encrypted files require their original RSA private key and file record, so keep a
backup of the previous project/database until you have confirmed which files are
still needed.

## Atlas preparation

The Atlas database user needs read/write access to the chosen database, and the
client IP address must be allowed in Atlas Network Access. On startup, the app
pings MongoDB and creates the required indexes.
