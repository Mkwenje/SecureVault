# Password features

## Show or hide a password

The login and registration windows now include a **Show password** checkbox.
The reset-password dialog includes **Show passwords** for the new and
confirmation fields.

## Reset a forgotten password

1. Open the login window.
2. Select **Forgot Password?**.
3. Enter the username.
4. Enter the current six-digit TOTP code from the authenticator app.
5. Enter and confirm a new password of at least eight characters.
6. Select **Reset Password**.

The application creates a new random salt and PBKDF2 password hash and updates
only those fields in the MongoDB `users` document. The user's RSA key pair and
TOTP secret are retained, so existing encrypted files remain accessible.

This recovery method requires access to the authenticator app. A user who has
lost both the password and the TOTP secret cannot use this reset flow. Recovery
codes or verified email recovery can be added as a separate future feature.
