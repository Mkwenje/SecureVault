package ie.ncirl.securevault.ui;

import ie.ncirl.securevault.auth.AuthService;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** SecureVault login window. */
public class LoginFrame extends JFrame {

    private final JTextField usernameField = new JTextField(20);
    private final JPasswordField passwordField = new JPasswordField(20);
    private final JTextField totpField = new JTextField(6);
    private final AuthService authService = new AuthService();

    public LoginFrame() {
        setTitle("SecureVault - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        gc.gridx = 0;
        gc.gridy = 0;
        panel.add(new JLabel("Username:"), gc);
        gc.gridx = 1;
        panel.add(usernameField, gc);

        gc.gridx = 0;
        gc.gridy = 1;
        panel.add(new JLabel("Password:"), gc);
        gc.gridx = 1;
        panel.add(passwordField, gc);

        JCheckBox showPasswordCheckBox = new JCheckBox("Show password");
        PasswordVisibility.bind(showPasswordCheckBox, passwordField);
        gc.gridx = 1;
        gc.gridy = 2;
        panel.add(showPasswordCheckBox, gc);

        gc.gridx = 0;
        gc.gridy = 3;
        panel.add(new JLabel("TOTP Code:"), gc);
        gc.gridx = 1;
        panel.add(totpField, gc);

        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");
        JButton forgotPasswordButton = new JButton("Forgot Password?");

        JPanel buttons = new JPanel();
        buttons.add(loginButton);
        buttons.add(registerButton);
        buttons.add(forgotPasswordButton);

        gc.gridx = 0;
        gc.gridy = 4;
        gc.gridwidth = 2;
        gc.anchor = GridBagConstraints.CENTER;
        panel.add(buttons, gc);

        setContentPane(panel);
        getRootPane().setDefaultButton(loginButton);

        loginButton.addActionListener(event -> doLogin());
        registerButton.addActionListener(event -> {
            new RegisterFrame(this).setVisible(true);
            setVisible(false);
        });
        forgotPasswordButton.addActionListener(event ->
                new ResetPasswordDialog(this, usernameField.getText()).setVisible(true)
        );
    }

    private void doLogin() {
        char[] password = passwordField.getPassword();

        try {
            String username = usernameField.getText().trim();
            String codeText = totpField.getText().trim();

            if (!codeText.matches("\\d{6}")) {
                throw new IllegalArgumentException("Enter a valid 6-digit TOTP code.");
            }

            boolean authenticated = authService.verifyLogin(
                    username,
                    password,
                    Integer.parseInt(codeText)
            );

            if (authenticated) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                new VaultDashboardFrame(username).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Login failed. Check your username, password and TOTP code.",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Login error: " + ex.getMessage(),
                    "Login Error",
                    JOptionPane.ERROR_MESSAGE
            );
        } finally {
            Arrays.fill(password, '\0');
            passwordField.setText("");
        }
    }
}
