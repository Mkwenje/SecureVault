package ie.ncirl.securevault.ui;

import ie.ncirl.securevault.auth.AuthService;
import ie.ncirl.securevault.auth.QrCodeUtil;
import ie.ncirl.securevault.auth.TotpUtil;
import ie.ncirl.securevault.model.User;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** SecureVault registration window. */
public class RegisterFrame extends JFrame {

    private final JTextField usernameField = new JTextField(20);
    private final JPasswordField passwordField = new JPasswordField(20);
    private final AuthService authService = new AuthService();
    private final JFrame parent;

    public RegisterFrame(JFrame parent) {
        this.parent = parent;

        setTitle("SecureVault - Register");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(480, 260);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        gc.gridx = 0;
        gc.gridy = 0;
        panel.add(new JLabel("Username:"), gc);
        gc.gridx = 1;
        panel.add(usernameField, gc);

        gc.gridx = 0;
        gc.gridy = 1;
        panel.add(new JLabel("Password:"), gc);
        gc.gridx = 1;
        panel.add(passwordField, gc);

        JCheckBox showPasswordCheckBox = new JCheckBox("Show password");
        PasswordVisibility.bind(showPasswordCheckBox, passwordField);
        gc.gridx = 1;
        gc.gridy = 2;
        panel.add(showPasswordCheckBox, gc);

        JButton createButton = new JButton("Create Account");
        JButton backButton = new JButton("Back to Login");

        JPanel buttons = new JPanel();
        buttons.add(createButton);
        buttons.add(backButton);

        gc.gridx = 0;
        gc.gridy = 3;
        gc.gridwidth = 2;
        gc.anchor = GridBagConstraints.CENTER;
        panel.add(buttons, gc);

        setContentPane(panel);
        getRootPane().setDefaultButton(createButton);

        createButton.addActionListener(event -> doRegister());
        backButton.addActionListener(event -> returnToLogin());

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent event) {
                parent.setVisible(true);
            }
        });
    }

    private void doRegister() {
        char[] password = passwordField.getPassword();

        try {
            String username = usernameField.getText().trim();
            User user = authService.register(username, password);

            String issuer = "SecureVault";
            String otpAuthUrl = TotpUtil.buildOtpAuthUrl(
                    username,
                    issuer,
                    user.getTotpSecret()
            );
            String qrFileName = "qrcode_" + username + ".png";
            QrCodeUtil.generateQrCode(otpAuthUrl, qrFileName, 320, 320);

            new QrSetupDialog(
                    this,
                    username,
                    user.getTotpSecret(),
                    qrFileName
            ).setVisible(true);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Registration error: " + ex.getMessage(),
                    "Registration Error",
                    JOptionPane.ERROR_MESSAGE
            );
        } finally {
            Arrays.fill(password, '\0');
            passwordField.setText("");
        }
    }

    private void returnToLogin() {
        dispose();
        parent.setVisible(true);
    }
}
