package ie.ncirl.securevault.auth;

import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import ie.ncirl.securevault.crypto.PasswordHasher;
import ie.ncirl.securevault.crypto.RsaKeyUtil;
import ie.ncirl.securevault.db.MongoConnection;
import ie.ncirl.securevault.model.User;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import org.bson.Document;
import org.bson.types.Binary;
import org.bson.types.ObjectId;
import com.mongodb.client.result.UpdateResult;

/** Handles registration, password/TOTP authentication and RSA user keys. */
public class AuthService {

    private final MongoCollection<Document> users;

    public AuthService() {
        MongoDatabase database = MongoConnection.getDatabase();
        this.users = database.getCollection("users");
    }

    public User register(String username, char[] password) throws Exception {
        String cleanUsername = username == null ? "" : username.trim();
        if (cleanUsername.isEmpty()) {
            throw new IllegalArgumentException("Username is required.");
        }
        validatePassword(password);

        String totpSecret = TotpUtil.generateSecret();
        byte[] salt = PasswordHasher.generateSalt();
        byte[] hash = PasswordHasher.hashPassword(password, salt);

        KeyPair keyPair = RsaKeyUtil.generateKeyPair();
        byte[] publicKeyBytes = keyPair.getPublic().getEncoded();
        byte[] privateKeyBytes = keyPair.getPrivate().getEncoded();

        ObjectId id = new ObjectId();
        Document document = new Document("_id", id)
                .append("username", cleanUsername)
                .append("passwordHash", new Binary(hash))
                .append("salt", new Binary(salt))
                .append("totpSecret", totpSecret)
                .append("publicKey", new Binary(publicKeyBytes))
                .append("privateKey", new Binary(privateKeyBytes))
                .append("createdAt", Instant.now());

        try {
            users.insertOne(document);
        } catch (MongoWriteException ex) {
            if (ex.getError() != null && ex.getError().getCode() == 11000) {
                throw new IllegalArgumentException("That username is already registered.", ex);
            }
            throw ex;
        }

        return new User(id.toHexString(), cleanUsername, hash, salt, totpSecret);
    }

    public User findByUsername(String username) {
        if (username == null || username.isBlank()) {
            return null;
        }

        Document document = users.find(Filters.eq("username", username.trim())).first();
        if (document == null) {
            return null;
        }

        Binary hash = document.get("passwordHash", Binary.class);
        Binary salt = document.get("salt", Binary.class);
        if (hash == null || salt == null) {
            throw new IllegalStateException("The user document is missing password data.");
        }

        return new User(
                document.getObjectId("_id").toHexString(),
                document.getString("username"),
                hash.getData(),
                salt.getData(),
                document.getString("totpSecret")
        );
    }

    public boolean verifyLogin(String username, char[] password, int totpCode) throws Exception {
        User user = findByUsername(username);
        if (user == null) {
            return false;
        }

        if (!PasswordHasher.verifyPassword(password, user.getSalt(), user.getPasswordHash())) {
            return false;
        }

        return TotpUtil.verifyCode(user.getTotpSecret(), totpCode, 1);
    }


    /**
     * Resets a user's password after verifying the current TOTP code. The RSA
     * key pair is not replaced, so files encrypted before the reset remain
     * decryptable by the same account.
     */
    public void resetPassword(String username, int totpCode, char[] newPassword) throws Exception {
        String cleanUsername = username == null ? "" : username.trim();
        validatePassword(newPassword);

        User user = findByUsername(cleanUsername);
        if (user == null || !TotpUtil.verifyCode(user.getTotpSecret(), totpCode, 1)) {
            throw new IllegalArgumentException("Unable to verify the username and TOTP code.");
        }

        if (PasswordHasher.verifyPassword(
                newPassword,
                user.getSalt(),
                user.getPasswordHash()
        )) {
            throw new IllegalArgumentException("The new password must be different from the current password.");
        }

        byte[] newSalt = PasswordHasher.generateSalt();
        byte[] newHash = PasswordHasher.hashPassword(newPassword, newSalt);

        UpdateResult result = users.updateOne(
                Filters.eq("_id", new ObjectId(user.getId())),
                Updates.combine(
                        Updates.set("passwordHash", new Binary(newHash)),
                        Updates.set("salt", new Binary(newSalt)),
                        Updates.set("passwordChangedAt", Instant.now())
                )
        );

        if (result.getMatchedCount() != 1) {
            throw new IllegalStateException("The password could not be updated.");
        }
    }

    public String getUserId(String username) {
        User user = findByUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("User not found.");
        }
        return user.getId();
    }

    public PublicKey getUserPublicKey(String userId) throws Exception {
        byte[] keyBytes = getKeyBytes(userId, "publicKey");
        if (keyBytes == null) {
            return null;
        }
        return KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(keyBytes));
    }

    public PrivateKey getUserPrivateKey(String userId) throws Exception {
        byte[] keyBytes = getKeyBytes(userId, "privateKey");
        if (keyBytes == null) {
            return null;
        }
        return KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
    }


    private static void validatePassword(char[] password) {
        if (password == null || password.length < 8) {
            throw new IllegalArgumentException("Password must contain at least 8 characters.");
        }
    }

    private byte[] getKeyBytes(String userId, String fieldName) {
        ObjectId objectId = parseObjectId(userId, "user");
        Document document = users.find(Filters.eq("_id", objectId))
                .projection(new Document(fieldName, 1))
                .first();
        if (document == null) {
            return null;
        }
        Binary binary = document.get(fieldName, Binary.class);
        return binary == null ? null : binary.getData();
    }

    private static ObjectId parseObjectId(String value, String label) {
        if (value == null || !ObjectId.isValid(value)) {
            throw new IllegalArgumentException("Invalid " + label + " identifier.");
        }
        return new ObjectId(value);
    }
}
