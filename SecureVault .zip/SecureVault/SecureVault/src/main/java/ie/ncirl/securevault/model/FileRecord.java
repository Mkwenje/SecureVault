package ie.ncirl.securevault.model;

/** Represents encrypted-file metadata stored in MongoDB. */
public class FileRecord {

    private String id;
    private String userId;
    private String originalPath;
    private String encryptedPath;
    private byte[] wrappedKey;

    public FileRecord() {
    }

    public FileRecord(String id, String userId, String originalPath,
                      String encryptedPath, byte[] wrappedKey) {
        this.id = id;
        this.userId = userId;
        this.originalPath = originalPath;
        this.encryptedPath = encryptedPath;
        this.wrappedKey = wrappedKey;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOriginalPath() {
        return originalPath;
    }

    public void setOriginalPath(String originalPath) {
        this.originalPath = originalPath;
    }

    public String getEncryptedPath() {
        return encryptedPath;
    }

    public void setEncryptedPath(String encryptedPath) {
        this.encryptedPath = encryptedPath;
    }

    public byte[] getWrappedKey() {
        return wrappedKey;
    }

    public void setWrappedKey(byte[] wrappedKey) {
        this.wrappedKey = wrappedKey;
    }
}
