package ie.ncirl.securevault.ui;

import ie.ncirl.securevault.auth.AuthService;
import ie.ncirl.securevault.crypto.AesGcmCrypto;
import ie.ncirl.securevault.crypto.KeyWrapUtil;
import ie.ncirl.securevault.db.MongoFileRecordDao;
import ie.ncirl.securevault.model.FileRecord;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Font;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.List;
import javax.crypto.SecretKey;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

/** Main SecureVault dashboard backed exclusively by MongoDB. */
public class VaultDashboardFrame extends JFrame {

    private final String username;
    private String userId;

    private final AuthService authService = new AuthService();
    private final MongoFileRecordDao fileDao = new MongoFileRecordDao();

    private final JCheckBox deleteOriginalCheck
            = new JCheckBox("Delete original after encryption");

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Original Path", "Encrypted Path"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public VaultDashboardFrame(String username) {
        this.username = username;

        setTitle("SecureVault - Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 420);
        setLocationRelativeTo(null);

        JLabel welcome = new JLabel("Welcome, " + username + "!", SwingConstants.LEFT);
        welcome.setFont(welcome.getFont().deriveFont(Font.BOLD, 16f));

        JButton encryptButton = new JButton("Encrypt File");
        JButton decryptButton = new JButton("Decrypt Selected");
        JButton refreshButton = new JButton("Refresh");
        JButton logoutButton = new JButton("Logout");

        JPanel top = new JPanel(new BorderLayout());
        top.add(welcome, BorderLayout.WEST);

        JPanel buttons = new JPanel();
        buttons.add(deleteOriginalCheck);
        buttons.add(encryptButton);
        buttons.add(decryptButton);
        buttons.add(refreshButton);
        buttons.add(logoutButton);
        top.add(buttons, BorderLayout.EAST);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        encryptButton.addActionListener(event -> encryptFileFlow());
        decryptButton.addActionListener(event -> decryptSelectedFlow());
        refreshButton.addActionListener(event -> refreshTable());
        logoutButton.addActionListener(event -> {
            new LoginFrame().setVisible(true);
            dispose();
        });

        try {
            userId = authService.getUserId(username);
            refreshTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Dashboard error: " + ex.getMessage());
        }
    }

    private void refreshTable() {
        try {
            tableModel.setRowCount(0);
            List<FileRecord> files = fileDao.getByUserId(userId);
            for (FileRecord record : files) {
                tableModel.addRow(new Object[]{
                    record.getId(),
                    record.getOriginalPath(),
                    record.getEncryptedPath()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Refresh error: " + ex.getMessage());
        }
    }

    private void encryptFileFlow() {
        try {
            JFileChooser inputChooser = new JFileChooser();
            inputChooser.setDialogTitle("Select a file to encrypt");
            if (inputChooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            Path input = inputChooser.getSelectedFile().toPath();

            JFileChooser outputChooser = new JFileChooser();
            outputChooser.setDialogTitle("Save encrypted file as...");
            outputChooser.setSelectedFile(
                    new java.io.File(input.getFileName().toString() + ".sv")
            );
            if (outputChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            Path output = outputChooser.getSelectedFile().toPath();

            SecretKey aesKey = AesGcmCrypto.generateKey();
            AesGcmCrypto.encryptFile(input, output, aesKey);

            PublicKey publicKey = authService.getUserPublicKey(userId);
            if (publicKey == null) {
                throw new IllegalStateException("The user's RSA public key was not found.");
            }

            byte[] wrappedKey = KeyWrapUtil.wrapKey(aesKey, publicKey);
            fileDao.insert(userId, input.toString(), output.toString(), wrappedKey);

            if (deleteOriginalCheck.isSelected()) {
                int confirm = JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete the original file?\n\n" + input,
                        "Confirm delete",
                        JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        Files.deleteIfExists(input);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(
                                this,
                                "Could not delete original file: " + ex.getMessage()
                        );
                    }
                }
            }

            JOptionPane.showMessageDialog(this, "File encrypted successfully.");
            refreshTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Encrypt error: " + ex.getMessage());
        }
    }

    private void decryptSelectedFlow() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a file record first.");
            return;
        }

        String fileId = String.valueOf(tableModel.getValueAt(row, 0));
        String originalPathText = String.valueOf(tableModel.getValueAt(row, 1));
        String encryptedPathText = String.valueOf(tableModel.getValueAt(row, 2));

        try {
            Path encryptedPath = Path.of(encryptedPathText);

            JFileChooser saveChooser = new JFileChooser();
            saveChooser.setDialogTitle("Save decrypted file as...");
            saveChooser.setSelectedFile(new java.io.File(
                    buildDecryptedFilename(originalPathText)
            ));
            if (saveChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            Path output = saveChooser.getSelectedFile().toPath();

            byte[] wrappedKey = fileDao.getWrappedKeyById(fileId, userId);
            if (wrappedKey == null || wrappedKey.length == 0) {
                throw new IllegalStateException("Wrapped key not found for this file record.");
            }

            PrivateKey privateKey = authService.getUserPrivateKey(userId);
            if (privateKey == null) {
                throw new IllegalStateException("The user's RSA private key was not found.");
            }

            SecretKey aesKey = KeyWrapUtil.unwrapKey(wrappedKey, privateKey);
            AesGcmCrypto.decryptFile(encryptedPath, output, aesKey);

            int open = JOptionPane.showConfirmDialog(
                    this,
                    "File decrypted successfully.\n\nOpen the decrypted file now?",
                    "Decryption Complete",
                    JOptionPane.YES_NO_OPTION
            );
            if (open == JOptionPane.YES_OPTION) {
                try {
                    Desktop.getDesktop().open(output.toFile());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Could not open file automatically:\n" + ex.getMessage()
                    );
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Decrypt error: " + ex.getMessage());
        }
    }

    private static String buildDecryptedFilename(String originalPathText) {
        String originalName = Path.of(originalPathText).getFileName().toString();
        int dot = originalName.lastIndexOf('.');
        if (dot > 0) {
            return originalName.substring(0, dot)
                    + "_decrypted"
                    + originalName.substring(dot);
        }
        return originalName + "_decrypted";
    }
}
