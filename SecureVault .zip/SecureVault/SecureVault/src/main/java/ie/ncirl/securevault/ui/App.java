package ie.ncirl.securevault.ui;

import ie.ncirl.securevault.db.MongoConnection;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/** SecureVault GUI entry point. */
public final class App {

    private App() {
    }

    public static void main(String[] args) {
        Runtime.getRuntime().addShutdownHook(new Thread(MongoConnection::close));

        try {
            MongoConnection.ping();
            MongoConnection.initializeIndexes();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "SecureVault could not connect to MongoDB.\n\n"
                    + ex.getMessage()
                    + "\n\nSet the MONGODB_URI environment variable and try again.",
                    "MongoDB Connection Error",
                    JOptionPane.ERROR_MESSAGE
            );
            MongoConnection.close();
            return;
        }

        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
