package ie.ncirl.securevault.securevault;

import ie.ncirl.securevault.auth.AuthService;
import ie.ncirl.securevault.auth.QrCodeUtil;
import ie.ncirl.securevault.auth.TotpUtil;
import ie.ncirl.securevault.db.MongoConnection;
import ie.ncirl.securevault.model.User;
import java.util.Scanner;

/** Optional console front-end used for development and testing. */
public final class SecureVault {

    private SecureVault() {
    }

    public static void main(String[] args) throws Exception {
        MongoConnection.ping();
        MongoConnection.initializeIndexes();

        try (Scanner scanner = new Scanner(System.in)) {
            AuthService authService = new AuthService();
            System.out.println("1) Register  2) Login");
            System.out.print("Choose option: ");
            int choice = Integer.parseInt(scanner.nextLine().trim());

            if (choice == 1) {
                doRegister(authService, scanner);
            } else if (choice == 2) {
                doLogin(authService, scanner);
            } else {
                System.out.println("Unknown option.");
            }
        } finally {
            MongoConnection.close();
        }
    }

    private static void doRegister(AuthService authService, Scanner scanner) throws Exception {
        System.out.print("Choose a username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Choose a password: ");
        char[] password = scanner.nextLine().toCharArray();
        User user;
        try {
            user = authService.register(username, password);
        } finally {
            java.util.Arrays.fill(password, '\0');
        }

        String secret = user.getTotpSecret();
        String otpAuthUrl = TotpUtil.buildOtpAuthUrl(username, "SecureVault", secret);
        String qrFileName = "qrcode_" + username + ".png";
        QrCodeUtil.generateQrCode(otpAuthUrl, qrFileName, 300, 300);

        System.out.println("User registered with MongoDB id=" + user.getId());
        System.out.println("QR file: " + qrFileName);
        System.out.println("Manual TOTP secret: " + secret);
    }

    private static void doLogin(AuthService authService, Scanner scanner) throws Exception {
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Password: ");
        char[] password = scanner.nextLine().toCharArray();

        System.out.print("TOTP code: ");
        int code = Integer.parseInt(scanner.nextLine().trim());

        boolean success;
        try {
            success = authService.verifyLogin(username, password, code);
        } finally {
            java.util.Arrays.fill(password, '\0');
        }
        System.out.println(success ? "Login successful." : "Login failed.");
    }
}
