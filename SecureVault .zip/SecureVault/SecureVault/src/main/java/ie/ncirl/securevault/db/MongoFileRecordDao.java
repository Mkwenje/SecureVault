package ie.ncirl.securevault.db;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import ie.ncirl.securevault.model.FileRecord;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.Binary;
import org.bson.types.ObjectId;

/** MongoDB data-access object for encrypted-file metadata. */
public class MongoFileRecordDao {

    private final MongoCollection<Document> collection;

    public MongoFileRecordDao() {
        MongoDatabase database = MongoConnection.getDatabase();
        this.collection = database.getCollection("file_records");
    }

    public String insert(String userId, String originalPath,
                         String encryptedPath, byte[] wrappedKey) {
        ObjectId recordId = new ObjectId();
        Document document = new Document("_id", recordId)
                .append("userId", parseObjectId(userId, "user"))
                .append("originalPath", originalPath)
                .append("encryptedPath", encryptedPath)
                .append("wrappedKey", new Binary(wrappedKey))
                .append("dateEncrypted", Instant.now());

        collection.insertOne(document);
        return recordId.toHexString();
    }

    public List<FileRecord> getByUserId(String userId) {
        ObjectId userObjectId = parseObjectId(userId, "user");
        List<FileRecord> results = new ArrayList<>();

        for (Document document : collection
                .find(Filters.eq("userId", userObjectId))
                .sort(Sorts.descending("dateEncrypted"))) {
            Binary wrappedKey = document.get("wrappedKey", Binary.class);
            results.add(new FileRecord(
                    document.getObjectId("_id").toHexString(),
                    userId,
                    document.getString("originalPath"),
                    document.getString("encryptedPath"),
                    wrappedKey == null ? null : wrappedKey.getData()
            ));
        }
        return results;
    }

    public byte[] getWrappedKeyById(String fileId, String userId) {
        Document document = collection.find(Filters.and(
                Filters.eq("_id", parseObjectId(fileId, "file record")),
                Filters.eq("userId", parseObjectId(userId, "user"))
        )).projection(new Document("wrappedKey", 1)).first();

        if (document == null) {
            return null;
        }
        Binary binary = document.get("wrappedKey", Binary.class);
        return binary == null ? null : binary.getData();
    }

    private static ObjectId parseObjectId(String value, String label) {
        if (value == null || !ObjectId.isValid(value)) {
            throw new IllegalArgumentException("Invalid " + label + " identifier.");
        }
        return new ObjectId(value);
    }
}
