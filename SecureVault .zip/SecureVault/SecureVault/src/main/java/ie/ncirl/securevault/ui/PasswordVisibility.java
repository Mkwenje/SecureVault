package ie.ncirl.securevault.ui;

import javax.swing.JCheckBox;
import javax.swing.JPasswordField;

/** Utility for safely toggling one or more Swing password fields. */
final class PasswordVisibility {

    private PasswordVisibility() {
    }

    static void bind(JCheckBox checkBox, JPasswordField... passwordFields) {
        if (checkBox == null || passwordFields == null || passwordFields.length == 0) {
            return;
        }

        char[] defaultEchoChars = new char[passwordFields.length];
        for (int i = 0; i < passwordFields.length; i++) {
            defaultEchoChars[i] = passwordFields[i].getEchoChar();
        }

        checkBox.addActionListener(event -> {
            boolean show = checkBox.isSelected();
            for (int i = 0; i < passwordFields.length; i++) {
                passwordFields[i].setEchoChar(show ? (char) 0 : defaultEchoChars[i]);
            }
        });
    }
}
