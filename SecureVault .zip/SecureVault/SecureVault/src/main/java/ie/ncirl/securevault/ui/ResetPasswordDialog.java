package ie.ncirl.securevault.ui;

import ie.ncirl.securevault.auth.AuthService;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * Password-reset dialog. The user's existing TOTP code is used as the recovery
 * factor, so resetting a password does not require email or a second database.
 */
public final class ResetPasswordDialog extends JDialog {

    private final JTextField usernameField = new JTextField(20);
    private final JTextField totpField = new JTextField(6);
    private final JPasswordField newPasswordField = new JPasswordField(20);
    private final JPasswordField confirmPasswordField = new JPasswordField(20);
    private final AuthService authService = new AuthService();

    public ResetPasswordDialog(Frame parent, String suggestedUsername) {
        super(parent, "SecureVault - Reset Password", true);

        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setSize(510, 340);
        setLocationRelativeTo(parent);
        setResizable(false);

        if (suggestedUsername != null) {
            usernameField.setText(suggestedUsername.trim());
        }

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        JLabel instruction = new JLabel(
                "<html>Enter the current 6-digit code from your authenticator app "
                + "to verify your identity.</html>"
        );
        gc.gridx = 0;
        gc.gridy = 0;
        gc.gridwidth = 2;
        gc.weightx = 1.0;
        panel.add(instruction, gc);

        gc.gridwidth = 1;
        gc.weightx = 0;
        gc.gridx = 0;
        gc.gridy = 1;
        panel.add(new JLabel("Username:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        panel.add(usernameField, gc);

        gc.gridx = 0;
        gc.gridy = 2;
        gc.weightx = 0;
        panel.add(new JLabel("TOTP Code:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        panel.add(totpField, gc);

        gc.gridx = 0;
        gc.gridy = 3;
        gc.weightx = 0;
        panel.add(new JLabel("New Password:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        panel.add(newPasswordField, gc);

        gc.gridx = 0;
        gc.gridy = 4;
        gc.weightx = 0;
        panel.add(new JLabel("Confirm Password:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        panel.add(confirmPasswordField, gc);

        JCheckBox showPasswordCheckBox = new JCheckBox("Show passwords");
        PasswordVisibility.bind(
                showPasswordCheckBox,
                newPasswordField,
                confirmPasswordField
        );
        gc.gridx = 1;
        gc.gridy = 5;
        gc.weightx = 1.0;
        panel.add(showPasswordCheckBox, gc);

        JButton resetButton = new JButton("Reset Password");
        JButton cancelButton = new JButton("Cancel");
        JPanel buttons = new JPanel();
        buttons.add(resetButton);
        buttons.add(cancelButton);

        gc.gridx = 0;
        gc.gridy = 6;
        gc.gridwidth = 2;
        gc.anchor = GridBagConstraints.CENTER;
        panel.add(buttons, gc);

        setContentPane(panel);
        getRootPane().setDefaultButton(resetButton);

        resetButton.addActionListener(event -> resetPassword());
        cancelButton.addActionListener(event -> dispose());
    }

    private void resetPassword() {
        char[] newPassword = newPasswordField.getPassword();
        char[] confirmedPassword = confirmPasswordField.getPassword();

        try {
            String username = usernameField.getText().trim();
            String codeText = totpField.getText().trim();

            if (!codeText.matches("\\d{6}")) {
                throw new IllegalArgumentException("Enter a valid 6-digit TOTP code.");
            }
            if (!Arrays.equals(newPassword, confirmedPassword)) {
                throw new IllegalArgumentException("The new passwords do not match.");
            }

            authService.resetPassword(username, Integer.parseInt(codeText), newPassword);

            JOptionPane.showMessageDialog(
                    this,
                    "Password reset successfully. You can now sign in with the new password.",
                    "Password Reset",
                    JOptionPane.INFORMATION_MESSAGE
            );
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Password reset error: " + ex.getMessage(),
                    "Unable to Reset Password",
                    JOptionPane.ERROR_MESSAGE
            );
        } finally {
            Arrays.fill(newPassword, '\0');
            Arrays.fill(confirmedPassword, '\0');
            newPasswordField.setText("");
            confirmPasswordField.setText("");
        }
    }
}
