package ie.ncirl.securevault.db;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import org.bson.Document;

/**
 * Central MongoDB connection manager for SecureVault.
 *
 * The connection string is deliberately not stored in source code. Configure it
 * using either the MONGODB_URI environment variable or the mongodb.uri JVM
 * system property. The database name can be set through MONGODB_DATABASE or
 * mongodb.database and defaults to "securevault".
 */
public final class MongoConnection {

    private static final String DEFAULT_DATABASE_NAME = "securevault";
    private static MongoClient mongoClient;

    private MongoConnection() {
    }

    private static String resolveUri() {
        String uri = System.getProperty("mongodb.uri");
        if (uri == null || uri.isBlank()) {
            uri = System.getenv("MONGODB_URI");
        }
        if (uri == null || uri.isBlank()) {
            throw new IllegalStateException(
                    "MongoDB connection string is not configured. Set MONGODB_URI "
                    + "or start the app with -Dmongodb.uri=<connection-string>."
            );
        }
        return uri.trim();
    }

    private static String resolveDatabaseName() {
        String name = System.getProperty("mongodb.database");
        if (name == null || name.isBlank()) {
            name = System.getenv("MONGODB_DATABASE");
        }
        return (name == null || name.isBlank()) ? DEFAULT_DATABASE_NAME : name.trim();
    }

    private static synchronized MongoClient getClient() {
        if (mongoClient == null) {
            mongoClient = MongoClients.create(resolveUri());
        }
        return mongoClient;
    }

    public static MongoDatabase getDatabase() {
        return getClient().getDatabase(resolveDatabaseName());
    }

    /** Forces a real server connection instead of only constructing a client. */
    public static void ping() {
        getDatabase().runCommand(new Document("ping", 1));
    }

    /** Creates the indexes required by the application. */
    public static void initializeIndexes() {
        MongoDatabase db = getDatabase();
        db.getCollection("users").createIndex(
                Indexes.ascending("username"),
                new IndexOptions().unique(true).name("uq_users_username")
        );
        db.getCollection("file_records").createIndex(
                Indexes.compoundIndex(
                        Indexes.ascending("userId"),
                        Indexes.descending("dateEncrypted")
                ),
                new IndexOptions().name("ix_file_records_user_date")
        );
    }

    public static synchronized void close() {
        if (mongoClient != null) {
            mongoClient.close();
            mongoClient = null;
        }
    }
}
